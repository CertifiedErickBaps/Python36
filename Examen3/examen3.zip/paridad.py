#Erick Bautista Perez A01379896

def paridad(bits):
    r = ""    
    if bits == bits[-1]:
        return bits + str(0)
    if bits[-1] in "1":
        return bits + str(0)
    elif bits[-1] in "0":
        return bits + str(1)
    
    return r
    
         
    
    
    
def main():
    print(paridad("1000110"))
    print(paridad("1011001"))
    print(paridad("0000000"))
    print(paridad("1111111"))
    print(paridad("0010000"))
    print(paridad("1101111"))
main()