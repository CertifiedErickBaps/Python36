#Erick Bautista Perez A01379896
def plural(palabra):
    r = ""    
    for c in palabra:
        if palabra[-1] in "aeiou":
            r = palabra + str("s")
        elif palabra[-1] in "z":
            r = palabra[:-1] + str("cez")
        else:
            r = palabra + str("es")
        return r
            
def main():
    print(plural("gato"))
    print(plural("puerta"))
    print(plural("zopilote"))
    print(plural("nuez"))
    print(plural("codorniz"))
    print(plural("cruz"))
    print(plural("animal"))
    print(plural("complot"))
    print(plural("hobits"))
main()
            