#Erick Bautista Perez
def euclides(a, b):
       
    while a != b:
        r = a % b
        if r != a:
            r % a
        return r    
    return a
        
def main():
    print(euclides(128, 48))
    print(euclides(25, 35))
    print(euclides(666, 150))
    print(euclides(10, 10))
main()

#resultado = 0    
#    while n != 0:
#        residuo = n % 10
#        n //= 10