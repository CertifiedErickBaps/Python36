# Authors: 
#          A01379896 Erick Bautista Pérez
#
#Write a program powers.py that prints a table of values of n and 2n for n = 1, 2, 3, ..., 10. You do not need to use any functions other than main().
#The program’s output should look like this:
#
# September 7, 2016.
def main():
    for i in range(1,11):
        print(i, 2**i)

main()