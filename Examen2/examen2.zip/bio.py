# Autor:
#          A01379896 Erick Bautista Pérez

# T=IC**n
def poblacion_total(I, C, n):
    return I * C ** n
    
def main(): 
    I = int(input("Poblacion inicial:" ))
    C = int(input("Numero de descendientes por progenitor: "))
    n = int(input("Numero de generacion: "))
    print("La poblacion total es", poblacion_total(I, C, n))
    
    
main()