# # Autor:
#          A01379896 Erick Bautista Pérez

def main():
    for i in range(1, 13, 1):
        m=12
        print(m, "x", i, "=", m*i )

main()