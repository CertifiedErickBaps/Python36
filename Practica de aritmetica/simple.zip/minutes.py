# Authors: 
#          A01379896 Erick Bautista Pérez
#          A01378568 Leonardo Valencia Benitez
# August 31, 2016.

#Write a program called minutes.py that calculates and prints the number of minutes 
#in a year (assume that a year has 365.25 days).

#1 año tiene 365.25 dias
#1 dia tiene 24 horas
#1 hora tiene 60 min

age=365.25 #days
day=24 #hours
hour=60 #minutes
B=int(age*day*hour)

print("The number of minutes in a year: ", B, "minutes")